#!/usr/bin/env python3

import aws_cdk as cdk

from aws_lambda.aws_lambda_stack import AwsLambdaStack
from glue.glue_etl_db_table import GlueEtlTbDb
from s3_stack.s3bucket import S3Stack
from glue.glue_etl_crawler import  GlueCrawlerStack
from glue.glue_etl_job import GlueCurJobStack
# from step_function.step_function import SfnGlueCdkStack

app = cdk.App()
aws_s3_stack = S3Stack(app,"S3Stack",stack_log_level="INFO")

aws_glue_db_stack = GlueEtlTbDb(app,"GlueEtlTbDb",stack_log_level="INFO")


aws_glue_job_stack = GlueCurJobStack(app,"GlueCurJobStack",
stack_log_level="INFO",
    glue_db_name=aws_glue_db_stack.glue_db_name.value_as_string,
    glue_table_name=aws_glue_db_stack.glue_table_name.value_as_string,
    etl_bkt=aws_s3_stack.data_bkt,
    description="Glue Job Stack"
)



aws_glue_crawler_stack = GlueCrawlerStack(app,"GlueCrawlerStack",stack_log_level="INFO",
    _glue_etl_role=aws_glue_job_stack._glue_etl_role,
    etl_bkt=aws_s3_stack.data_bkt,
    etl_bkt_prefix=aws_glue_job_stack.etl_prefix,
    glue_db_name=aws_glue_db_stack.glue_db_name.value_as_string,
    description="Glue Crawler Stack")

# SfnGlueCdkStack(app, "SfnGlueCdkExample",glue_job_name= aws_glue_job_stack.etl_job_name)
aws_lambda_stack = AwsLambdaStack(app, "AwsLambdaStack",glue_job_name= aws_glue_job_stack.etl_job_name,

    )

app.synth()
