import json
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

import boto3
client = boto3.client('glue')


def handler(event, job_name,context):
    print('request: {}'.format(json.dumps(event)))
    logger.info('## INITIATED BY EVENT: ')
    logger.info(event['detail'])
    response = client.start_job_run(JobName=job_name)
    logger.info('## STARTED GLUE JOB: ' + job_name)
    logger.info('## GLUE JOB RUN ID: ' + response['JobRunId'])
    return response
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/plain'
        },
        'body': 'Hello, CDK! You have hit {}\n'.format(event['path'])
    }