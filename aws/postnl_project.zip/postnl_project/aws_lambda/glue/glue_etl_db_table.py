import aws_cdk as cdk

from aws_cdk import (
    # Duration,
    aws_glue as _glue)

from constructs import Construct

class GlueEtlTbDb(cdk.Stack):

    def __init__(
            self,
            scope: Construct,
            construct_id: str,
            stack_log_level: str,
            **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)



        self.glue_db_name = cdk.CfnParameter(
            self,
            "curreportdb",
            type="String",
            description="Name of Glue Database to be created for CUR report.",
            allowed_pattern="[\w-]+",
            default="cur_report_db",
        )

        self.glue_table_name = cdk.CfnParameter(
            self,
            "curreport",
            type="String",
            description="Name of Glue Table to be created for CUR report.",
            allowed_pattern="[\w-]+",
            default="cur_report_tbl",
        )

        cfn_db = _glue.CfnDatabase(
            self,
            "curdb",
            catalog_id=cdk.Aws.ACCOUNT_ID,
            database_input=_glue.CfnDatabase.DatabaseInputProperty(
                name=self.glue_db_name.value_as_string,
                description="Database for CUR report."

            ),
        )

        # Ref: https://docs.aws.amazon.com/glue/latest/dg/add-job-streaming.html
        cfn_table = _glue.CfnTable(
            self,
            "curreporttable",
            catalog_id=cfn_db.catalog_id,
            database_name=self.glue_db_name.value_as_string,
            table_input=_glue.CfnTable.TableInputProperty(
                description="CUR report Table",
                name=self.glue_table_name.value_as_string,
                parameters={
                    "classification": "csv",
                    "typeOfData": "file"
                },

                table_type="EXTERNAL_TABLE",
                storage_descriptor=_glue.CfnTable.StorageDescriptorProperty(

                    location=f"s3://postnlbusket/postnl/postnl_report/20220801-20220901/20220823T233621Z/postnl_report-00001.csv.gz",
                    parameters={
                        "key": "field.delim",

                    },
                    input_format="org.apache.hadoop.mapred.TextInputFormat",
                    output_format="org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                    serde_info=_glue.CfnTable.SerdeInfoProperty(
                        name="CUR scale",
                        serialization_library="org.openx.data.jsonserde.JsonSerDe",
                        parameters={
                            "paths": "",
                            # "typeOfData": "file"
                        }
                    )
                )
            )
        )

        cfn_table.add_depends_on(cfn_db)
        output_0 = cdk.CfnOutput(
            self,
            "CUR",
            value=f"https://console.aws.amazon.com/glue/home?region={cdk.Aws.REGION}#table:catalog={cdk.Aws.ACCOUNT_ID};name={self.glue_table_name.value_as_string};namespace={self.glue_db_name.value_as_string}",
            description="Glue CUR Table.",
        )

