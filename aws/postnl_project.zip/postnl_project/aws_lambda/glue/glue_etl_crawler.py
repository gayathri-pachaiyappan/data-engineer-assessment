from aws_cdk import aws_glue as _glue
import aws_cdk as cdk

from constructs import Construct

class GlueCrawlerStack(cdk.Stack):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        stack_log_level: str,
        _glue_etl_role,
        etl_bkt,
        etl_bkt_prefix,
        glue_db_name: str,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)



        # Glue Crawler
        cur_crawler = _glue.CfnCrawler(
            self,
            "glueCrawler",
            name="cur_crawler",
            role=_glue_etl_role.role_arn,
            database_name=f"{glue_db_name}",
            table_prefix="cur_",
            description=" Crawl the cur report store in table to enable for reporting",
            targets={
                "s3Targets": [
                    {
                        "path": f"s3://{etl_bkt.bucket_name}/{etl_bkt_prefix}",
                        "exclusions": ["checkpoint/**"]
                    }
                ]
            },
            configuration="{\"Version\":1.0,\"CrawlerOutput\":{\"Partitions\":{\"AddOrUpdateBehavior\":\"InheritFromTable\"},\"Tables\":{\"AddOrUpdateBehavior\":\"MergeNewColumns\"}}}",
            schedule=_glue.CfnCrawler.ScheduleProperty(
                schedule_expression="cron(0 * * * ? *)"
            )
        )
        # Configuration As JSON in human readable format
        """
        {
            "Version": 1,
            "CrawlerOutput": {
                "Partitions": {
                    "AddOrUpdateBehavior": "InheritFromTable"
                },
                "Tables": {
                    "AddOrUpdateBehavior": "MergeNewColumns"
                }
            }
        }
        and SchemaChangePolicy 
        {
            "UpdateBehavior": "UPDATE_IN_DATABASE",
            "DeleteBehavior": "DEPRECATE_IN_DATABASE"
        }
        """

        ###########################################
        ################# OUTPUTS #################
        ###########################################


        output_1 = cdk.CfnOutput(
            self,
            "SaleTransactionsCrawler",
            value=f" https://console.aws.amazon.com/glue/home?region={cdk.Aws.REGION}#crawler:name={cur_crawler.name}",
            description="Glue ETL Job.",
        )
