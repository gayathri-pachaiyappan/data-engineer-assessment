
from aws_cdk import (
    # Duration,
    Stack,
    aws_lambda as _lambda,
    aws_iam as _iam
)

from constructs import Construct


class AwsLambdaStack(Stack):



    def __init__(self, scope: Construct, construct_id: str,glue_job_name: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)


        lambda_role = _iam.Role(scope=self,id='cdk-lambda-role',
                                assumed_by=_iam.ServicePrincipal('lambda.amazonaws.com'),
                                role_name='cdk-lambda-role',
                                managed_policies=[
                                    _iam.ManagedPolicy.from_aws_managed_policy_name(
                                        'service-role/AWSLambdaVPCAccessExecutionRole'),
                                    _iam.ManagedPolicy.from_aws_managed_policy_name(
                                        'service-role/AWSLambdaBasicExecutionRole')
                                ])

        

        cur_lambda = _lambda.Function(self, "CUR_Jobtrigger_Lambda",  # lambda function name
                                         handler="lambda_handler.handler",  # function name as defined
                                         runtime=_lambda.Runtime.PYTHON_3_9,  # runtime
                                         code=_lambda.Code.from_asset('lambda'),
                                         role=lambda_role,
                                      environment={'job_name':
                                                       glue_job_name}
                                         )  # path to lambda handler



